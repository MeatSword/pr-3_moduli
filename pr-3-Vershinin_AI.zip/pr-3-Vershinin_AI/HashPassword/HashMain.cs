﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HashPassword
{
    public static class HashMain
    {
        public static string GetHash(string password)
        {
            SHA256 sh = SHA256.Create();
            byte[] sourceBytePassw = Encoding.UTF8.GetBytes(password);
            byte[] hashsource = sh.ComputeHash(sourceBytePassw);

            string hashPassword = BitConverter.ToString(hashsource).Replace("-", String.Empty);

            return hashPassword;
        }
    }
}
