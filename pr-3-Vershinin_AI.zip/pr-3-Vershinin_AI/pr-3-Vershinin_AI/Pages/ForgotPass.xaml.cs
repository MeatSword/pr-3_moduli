﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Mail;

namespace pr_3_Vershinin_AI.Pages
{
    /// <summary>
    /// Логика взаимодействия для ForgotPass.xaml
    /// </summary>
    public partial class ForgotPass : Page
    {
        public ForgotPass()
        {
            InitializeComponent();
            
        }

        private static async Task SendEmailAsync()
        {
            //tnkcfcgujwwjadai
            MailAddress from = new MailAddress("alekseyfamil459@gmail.com", "Aleksandr");
            MailAddress to = new MailAddress("thealexmaps@yandex.ru");
            MailMessage m = new MailMessage(from, to);
            m.Subject = "CodePR9";
            m.Body = "Test";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.Credentials = new NetworkCredential("alekseyfamil459@gmail.com", "olclsousxiyvkhvc");
            smtp.EnableSsl = true;
            
            await smtp.SendMailAsync(m);
        }

        private void Forgotten_Click(object sender, RoutedEventArgs e)
        {
            SendEmailAsync().GetAwaiter();
        }
    }
}
