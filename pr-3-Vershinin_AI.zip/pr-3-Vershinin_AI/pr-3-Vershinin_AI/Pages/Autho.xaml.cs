﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HashPassword;

namespace pr_3_Vershinin_AI.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        Employes emp;
        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
        int _count = 0,sec=10;
        public Autho()
        {
            InitializeComponent();
            
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }

        private void btnEntGuests_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(emp));
        }

        private void btnEnt_Click(object sender, RoutedEventArgs e)
        {

            EntPage(Login());
        }
        string Login()
        {
            string role = "Admin";
            string log = txtLog.Text.Trim();
            string pass = HashMain.GetHash(psbPass.Password.Trim());

            Entities db = DBHelper.GetContext();
            
            if(db.EmployesLog.Where(_=>_.password== pass && _.login==log).Any() ) {

                emp = db.EmployesLog.Where(_ => _.password == pass && _.login == log).FirstOrDefault().Employes;
                
                if (db.Roles.Where(_ => _.id == emp.roleid).FirstOrDefault().name=="Admin")
                {
                    role = "Admin";
                }
                else if(db.Roles.Where(_ => _.id == emp.roleid).FirstOrDefault().name == "Common")
                {
                    role = "User";
                }
                    
            }
            else
            {
                txtCaptcha.Visibility = Visibility.Visible;
                lbCaptcha.Visibility = Visibility.Visible;
                
                MessageBox.Show("Неправильные данные входа");
                Captcha();
                _count++;

                if (_count == 3)
                {
                    txtLog.IsEnabled = false;
                    txtCaptcha.IsEnabled = false;
                    psbPass.IsEnabled = false;
                    lbCaptcha.IsEnabled = false;
                    btnEnt.IsEnabled = false;
                    btnEntGuests.IsEnabled = false;
                    lbTimer.Visibility = Visibility.Visible;
                }

            }
            return role;
        }
        void Captcha()
        {
            string text = "";

            Random r = new Random();
            int count = r.Next(10, 16);

            for(int i=0; i<count; i++)
            {
                char c = Convert.ToChar(r.Next(48, 126));
                text+= c;
            }
            txtCaptcha.Text= text;  
        }
        void EntPage(string role)
        {
            if (txtCaptcha.Text == lbCaptcha.Text )
            {
                if(CheckRabTime())
                {
                    if (role == "User")
                    {
                        NavigationService.Navigate(new Client(emp));
                    }
                    if (role == "Admin")
                    {
                        NavigationService.Navigate(new Admin(emp));
                    }
                }
                else
                {
                    MessageBox.Show("Не рабочее время");
                }
               
            }
            else
            {
                MessageBox.Show("Капча неверна");
            }

        }
       


        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (sec>=0 && _count==3)
            {
                
                lbTimer.Text=sec.ToString();
                sec--;
            }
            else if(sec<0)
            {
                txtLog.IsEnabled = true;
                txtCaptcha.IsEnabled = true;
                psbPass.IsEnabled = true;
                lbCaptcha.IsEnabled = true;
                btnEnt.IsEnabled = true;
                btnEntGuests.IsEnabled = true;
                lbTimer.Visibility = Visibility.Hidden;

                _count = 0;
                sec = 10;
                lbTimer.Text = sec.ToString();
            }
            
        }

        private void Forgotten_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ForgotPass());
        }

        bool CheckRabTime()
        {
            DateTime dt = DateTime.Now;
            
            if (dt.Hour<=19 && dt.Hour>=10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
