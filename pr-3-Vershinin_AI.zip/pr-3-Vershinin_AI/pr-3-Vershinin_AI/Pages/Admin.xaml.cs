﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr_3_Vershinin_AI.Pages
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Page
    {
        public Admin(Employes emp)
        {
            InitializeComponent();

            txtName.Text = $"Добрый {HelloTime()}, {emp.name}";
            txtSName.Text = emp.sname;
            txtLName.Text = emp.lname;
            txtPhone.Text = emp.phone;
        }
        string HelloTime()
        {
            string msg = "";
            DateTime dt = DateTime.Now;
            
            if(dt.Hour>=10 && dt.Hour<12)
            {
                msg="Утро";
            }
            if (dt.Hour >= 12 && dt.Hour < 17)
            {
                msg= "День";
            }
            if (dt.Hour >= 17 && dt.Hour < 19)
            {
                msg= "Вечер";
            }
            return msg;
        }

        private void btnEnt_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EmployesList());
        }
    }
}
