﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace pr_3_Vershinin_AI.Pages
{
    /// <summary>
    /// Логика взаимодействия для EmployesList.xaml
    /// </summary>
    public partial class EmployesList : Page
    {
        int has = 0;
        Entities bd;
        List<Employes> employe;
        public EmployesList()
        {
            bd=DBHelper.GetContext();

            InitializeComponent();

            employe= new List<Employes>();
            employe = bd.Employes.ToList();
            Refresh(employe);
        }
        void Refresh(List<Employes> employes)
        {
            LViewProduct.ItemsSource = employes;
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                Search();
            }
        }
        void Search()
        {
            List<Employes> emp = bd.Employes.ToList();
            List<Employes> emp1 = bd.Employes.ToList();
            foreach (Employes emps in emp1)
            {
                string text = (emps.name + " " + emps.sname + " " +emps.lname); 
                if(!text.Contains(txtSearch.Text))
                {
                    emp.Remove(emps);
                }
            }
            Refresh(emp);
            

        }

        private void cmbSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if((sender as ComboBox).SelectedIndex ==1)
            {
                List<Employes> emp = bd.Employes.ToList();
                List<Employes> empExit = new List<Employes>();

                while(emp.Count!=0)
                {
                    Employes[] cnt = new Employes[emp.Count];

                    for(int i=0;i<cnt.Length;i++)
                    {   
                        cnt[i] = emp[i];
                    }

                    foreach(Employes fp in cnt)
                    {
                        if(Check(emp)=="Admin")
                        {
                            if(fp.Roles.name=="Admin")
                            {
                                empExit.Add(fp);
                                emp.Remove(fp);
                            }
                            
                        }
                        if (Check(emp) == "Manager")
                        {
                            if (fp.Roles.name == "Manager")
                            {
                                empExit.Add(fp);
                                emp.Remove(fp);
                            }

                        }
                        if (Check(emp) == "Common")
                        {
                            if (fp.Roles.name == "Common")
                            {
                                empExit.Add(fp);
                                emp.Remove(fp);
                            }

                        }
                    }
                }
                Refresh(empExit);
            }
            if ((sender as ComboBox).SelectedIndex == 0)
            {
                if(has==0)
                {
                    has++;
                }
                else
                {
                    employe = bd.Employes.ToList();
                    Refresh(employe);
                }
                
            }
        }
        string Check(List<Employes> f)
        {
            int i = 0;
            string t = "";
            while(t=="")
            {
                if(i==0)
                {
                    foreach (Employes e in f)
                    {
                        if (e.Roles.name == "Admin")
                        {
                            t = "Admin";
                        }
                    }
                }
                if(i==1)
                {
                    foreach (Employes e in f)
                    {
                        if (e.Roles.name == "Manager")
                        {
                            t = "Manager";
                        }
                    }
                }
                if (i == 2)
                {
                    foreach (Employes e in f)
                    {
                        if (e.Roles.name == "Common")
                        {
                            t = "Common";
                        }
                    }
                }
                i++;

            }
            
            return t;
        }

        private void btnEnt_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ClientEditN());
        }

        private void LViewProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Employes emp = bd.Employes.Where(_ => _.id == LViewProduct.SelectedIndex+1).FirstOrDefault();
            NavigationService.Navigate(new ClientEditN(emp));
        }

        private void btnEntR_Click(object sender, RoutedEventArgs e)
        {
            employe = bd.Employes.ToList();
            cmbFilter.SelectedIndex = 0;
            cmbSorting.SelectedIndex = 0;
            Refresh(employe);
        }

        private void cmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if ((sender as ComboBox).SelectedIndex == 1)
            {
                List<Employes> emp = bd.Employes.ToList();
                List<Employes> empExit = new List<Employes>();

                for(int i = 0; i < emp.Count; i++) 
                {
                    if (emp[i].Roles.name == "Admin")
                    {
                        empExit.Add(emp[i]);
                    }
                }
                Refresh(empExit);
            }
            if ((sender as ComboBox).SelectedIndex == 2)
            {
                List<Employes> emp = bd.Employes.ToList();
                List<Employes> empExit = new List<Employes>();

                for (int i = 0; i < emp.Count; i++)
                {
                    if (emp[i].Roles.name == "Manager")
                    {
                        empExit.Add(emp[i]);
                    }
                }
                Refresh(empExit);
            }
            if ((sender as ComboBox).SelectedIndex == 3)
            {
                List<Employes> emp = bd.Employes.ToList();
                List<Employes> empExit = new List<Employes>();

                for (int i = 0; i < emp.Count; i++)
                {
                    if (emp[i].Roles.name == "Common")
                    {
                        empExit.Add(emp[i]);
                    }
                }
                Refresh(empExit);
            }
            if ((sender as ComboBox).SelectedIndex == 0)
            {
                if (has==1)
                {
                    has ++;
                }
                else
                {
                    employe = bd.Employes.ToList();
                    Refresh(employe);
                }

            }
        }
    }
}
