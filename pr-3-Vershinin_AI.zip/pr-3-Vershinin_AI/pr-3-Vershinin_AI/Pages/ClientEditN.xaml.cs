﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HashPassword;
using System.Xml.Linq;
using TrueValid = System.ComponentModel.DataAnnotations.ValidationResult;

namespace pr_3_Vershinin_AI.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientEditN.xaml
    /// </summary>
    /// 
    
    public partial class ClientEditN : Page
    {
        Employes emp;
        public ClientEditN()
        {
            InitializeComponent();
            emp = null;
        }
        public ClientEditN(Employes em)
        {
            InitializeComponent();
            emp = em;
            txtName.Text = em.name;
            txtLName.Text = em.lname;
            txtSName.Text = em.sname;
            txtPhone.Text = em.phone;
            txtUser.Visibility = Visibility.Hidden;
            txtPass.Visibility = Visibility.Hidden;
            cmbSorting.SelectedIndex = em.roleid-1;   
        }

        private void btnEnt_Click(object sender, RoutedEventArgs e)
        {
            if(emp == null)
            {
                Entities db = new Entities();
                Employes emp = new Employes();
                EmployesLog empLg = new EmployesLog();

                try
                {
                    emp.name = txtName.Text;
                    emp.sname = txtSName.Text;
                    emp.lname = txtLName.Text;
                    emp.phone = txtPhone.Text;
                    emp.roleid = cmbSorting.SelectedIndex + 1;
                    emp.idautocenter = 1;
                    db.Employes.Add(emp);
                    db.SaveChanges();

                    empLg.id = emp.id;
                    empLg.login = txtUser.Text;
                    empLg.password = HashMain.GetHash(txtPass.Text);
                    db.EmployesLog.Add(empLg);
                    db.SaveChanges();
                }
                catch
                {
                    var context = new ValidationContext(emp);
                    var results = new List<TrueValid>();

                    if (!Validator.TryValidateObject(emp, context, results, true))
                    {
                        string msg = "";
                        MessageBox.Show("Не удалось создать объект User");
                        foreach (var error in results)
                        {
                            msg += error.ErrorMessage + "\n";
                        }
                        MessageBox.Show(msg);
                    }
                }
                
                
            }
            else
            {
                Entities db = new Entities();
                Employes emps = db.Employes.Where(_=>_.id==emp.id).FirstOrDefault();
               

                emp.name = txtName.Text;
                emp.sname = txtSName.Text;
                emp.lname = txtLName.Text;
                emp.phone = txtPhone.Text;
                emp.roleid = cmbSorting.SelectedIndex + 1;
                emp.idautocenter = 1;
                db.SaveChanges();
            }
            
        }
    }
}
