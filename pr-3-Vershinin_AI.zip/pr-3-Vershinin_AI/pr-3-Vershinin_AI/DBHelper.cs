﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_3_Vershinin_AI
{
    internal static class DBHelper
    {
        static Entities f_db;

        public static Entities GetContext()
        {
            if(f_db==null)
            {
                f_db= new Entities();
            }
            return f_db;
        }
    }
}
